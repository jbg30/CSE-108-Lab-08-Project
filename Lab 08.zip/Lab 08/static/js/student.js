document.addEventListener('DOMContentLoaded', () => {
  const path = window.location.pathname;

  if (path.includes('/student/login')) initStudentLogin();
  if (path.includes('/student/dashboard')) loadStudentDashboard();
  if (path.includes('/student/register')) loadClassRegistration();
});

// ---------- Login ----------
function initStudentLogin() {
  const loginBtn = document.getElementById('studentLoginBtn');
  const msg = document.getElementById('stuLoginMsg');

  loginBtn?.addEventListener('click', () => {
    const email = document.getElementById('studentLoginEmail').value.trim();
    const password = document.getElementById('studentLoginPassword').value.trim();

    if (!email || !password) {
      msg.textContent = 'Please enter email and password.';
      return;
    }

    // mock login
    sessionStorage.setItem('userEmail', email);
    sessionStorage.setItem('role', 'student');
    msg.textContent = 'Logging in...';
    window.location.href = '/student/dashboard';
  });
}

// ---------- Dashboard ----------
function loadStudentDashboard() {
  const msg = document.getElementById('studentDashboardMsg');
  const enrolledTable = document.querySelector('#enrolledTable tbody');
  enrolledTable.innerHTML = '';

  // sample enrolled classes
  const enrolled = [
    {name: 'Intro to Web', professor: 'Dr. A', credits: 3},
    {name: 'Data Structures', professor: 'Dr. B', credits: 4}
  ];

  enrolled.forEach(c => {
    const row = document.createElement('tr');
    row.innerHTML = `<td>${c.name}</td><td>${c.professor}</td><td>${c.credits}</td>`;
    enrolledTable.appendChild(row);
  });

  // register for classes button
  const registerBtn = document.getElementById('registerClassesBtn');
  registerBtn?.addEventListener('click', () => {
    window.location.href = '/student/register';
  });
}

// ---------- Class Registration ----------
function loadClassRegistration() {
  const table = document.querySelector('#classCatalog tbody');
  const msg = document.getElementById('classListMsg');
  table.innerHTML = '';

  const available = [
    {id:1, name:'Algorithms', professor:'Dr. C', enrolled:20, capacity:25},
    {id:2, name:'Databases', professor:'Dr. D', enrolled:25, capacity:25},
    {id:3, name:'AI Basics', professor:'Dr. E', enrolled:10, capacity:15}
  ];

  available.forEach(c => {
    const row = document.createElement('tr');
    row.innerHTML = `<td>${c.name}</td><td>${c.professor}</td><td>${c.enrolled}/${c.capacity}</td>
      <td><button class="btn" onclick="joinClass(${c.id})" ${c.enrolled >= c.capacity ? 'disabled' : ''}>Join</button></td>`;
    table.appendChild(row);
  });
}

function joinClass(classId) {
  alert(`Attempted to join class ${classId} (frontend-only).`);
}

// ---------- Logout ----------
function logoutStudent() {
  sessionStorage.clear();
  window.location.href = '/student/login';
}
