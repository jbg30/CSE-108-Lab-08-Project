from flask import Flask, jsonify, request, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///grades.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    grade = db.Column(db.Float, nullable=False)

    def to_dict(self):
        return {self.name: self.grade}

with app.app_context():
    db.create_all()

@app.route("/")
def index():
    return render_template("index.html")


# New with Lab 08 (student routes)
@app.route("/student/login")
def student_login():
    return render_template("student_login.html")

@app.route("/student/dashboard")
def student_dashboard():
    # dashboard will use client-side fetch to pull classes when backend exists
    return render_template("student_dashboard.html")

@app.route("/student/register")
def student_register():
    return render_template("student_register.html")


# New with Lab 08 (professor routes)
@app.route("/professor/dashboard")
def professor_dashboard():
    # dashboard will use client-side fetch to pull classes when backend exists
    return render_template("professor_dashboard.html")


# New with Lab 08 (admin routes)
@app.route("/admin/dashboard")
def admin_dashboard():
    # dashboard will use client-side fetch to pull classes when backend exists
    return render_template("admin_dashboard.html")


# Section: All Grades
@app.route("/api/grades", methods=["GET"])
def get_all_grades():
    students = Student.query.all()
    return jsonify({s.name: s.grade for s in students})

# Section: Get Grade
@app.route("/api/grades/<string:name>", methods=["GET"])
def get_grade(name):
    student = Student.query.filter_by(name=name).first()
    if not student:
        return jsonify({"error": "Student not found"}), 404
    return jsonify({student.name: student.grade})

# Section: Add new student
@app.route("/api/grades", methods=["POST"])
def add_student():
    data = request.get_json()
    name = data.get("name")
    grade = data.get("grade")

    if not name or grade is None:
        return jsonify({"error": "Name and grade required"}), 400

    existing = Student.query.filter_by(name=name).first()
    if existing:
        return jsonify({"error": "Student already exists"}), 400

    new_student = Student(name=name, grade=grade)
    db.session.add(new_student)
    db.session.commit()

    return jsonify({name: grade}), 201

# Section: Edit Grade
@app.route("/api/grades/<string:name>", methods=["PUT"])
def edit_student(name):
    student = Student.query.filter_by(name=name).first()
    if not student:
        return jsonify({"error": "Student not found"}), 404

    data = request.get_json()
    grade = data.get("grade")
    if grade is None:
        return jsonify({"error": "Grade required"}), 400

    student.grade = grade
    db.session.commit()
    return jsonify({student.name: student.grade})

# Section: Delete
@app.route("/api/grades/<string:name>", methods=["DELETE"])
def delete_student(name):
    student = Student.query.filter_by(name=name).first()
    if not student:
        return jsonify({"error": "Student not found"}), 404

    db.session.delete(student)
    db.session.commit()
    return jsonify({"message": f"{name} deleted successfully"})

if __name__ == "__main__":
    app.run(debug=True)
